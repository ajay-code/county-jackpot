module.exports = [
    {
        id: 1,
        name: '1.jpg'
    },
    {
        id: 2,
        name: '2.jpg'
    },
    {
        id: 3,
        name: '3.jpg'
    },
    {
        id: 4,
        name: '4.jpg'
    },
    {
        id: 5,
        name: '5.jpg'
    },
    {
        id: 6,
        name: '6.jpg'
    },
    {
        id: 7,
        name: '7.jpg'
    },
    {
        id: 8,
        name: '8.jpg'
    },
    {
        id: 9,
        name: '9.jpeg'
    },
    {
        id: 10,
        name: '10.jpg'
    },
    {
        id: 11,
        name: '11.jpeg'
    },
    {
        id: 12,
        name: '12.jpeg'
    },
    {
        id: 13,
        name: '13.jpeg'
    },
    {
        id: 14,
        name: '14.jpg'
    },
    {
        id: 15,
        name: '15.jpg'
    },
    {
        id: 16,
        name: '16.jpg'
    },

]